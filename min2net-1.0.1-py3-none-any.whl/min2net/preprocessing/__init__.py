from .FBCSP import FBCSP
from .SpectralSpatialMapping import SpectralSpatialMapping
from . import BCIC2a
from . import SMR_BCI
from . import OpenBMI
from . import config