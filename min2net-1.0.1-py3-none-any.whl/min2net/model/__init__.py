from .MIN2Net import MIN2Net
from .MIN2Net_without_triplet import MIN2Net_without_triplet
from .DeepConvNet import DeepConvNet
from .EEGNet import EEGNet
from .SVM import SVM
from .SpectralSpatialCNN import SpectralSpatialCNN
from .MIN2Net_without_decoder import MIN2Net_without_decoder